clc; clear; close all;
addpath(genpath([pwd]));
%load('aadyotcodes/data_face.mat')
load('photon efficient computational 3d 2015(ROM CENSORING)/sample-data/data_chart_intensity.mat')
range_refl =[0,20];
range_depth = [3550,3700];
window_length = 100;
Ts = photonArrivals;

% method 1
[avg_tof, counts] = estimating(Ts);
figure; 
subplot(321); imagesc(counts); axis image;
title('reflectivity - ML');
subplot(322); imagesc(avg_tof); axis image;
title('depth - ML');
colormap('gray');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

censoredTs = windowing(Ts, window_length);
[avg_tof, counts] = estimating(censoredTs);

subplot(323); imagesc(counts); axis image;
title('reflectivity - windowing + ML');
subplot(324); imagesc(avg_tof); axis image;
title('depth - windowing + ML');
colormap('gray');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

censoredTs = windowing(Ts, window_length);
[avg_tof, counts] = estimating(censoredTs);
superTimes = superpixeling(censoredTs, avg_tof, counts, 2, 100, 5);

censoredTs = windowing(superTimes, window_length/9);
[avg_tof, counts] = estimating(censoredTs);


subplot(325); imagesc(counts); axis image;
title('reflectivity - superpixeling + windowing + ML');
subplot(326); imagesc(avg_tof); axis image;
title('depth - superpixeling + windowing + ML');
colormap('gray');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




