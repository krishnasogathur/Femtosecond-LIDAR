%clc; clear; close all;
%data = cell(3,3);
%data{1,1} = [1,11];
%%data{1,2} = [2,12];
%data{1,3} = [3,13];
%data{2,1} = [4,14];
%data{2,2} = [5,15];
%data{2,3} = [6,16];
%data{3,1} = [7,17];
%data{3,2} = [8,18];
%data{3,3} = [9,19];
%dep = [1,1,2;1,2,2;3,3,3];
%ref = dep*0;

%superpixelin1g(data, dep, ref, 1, 1, 1)

function combined_times = superpixeling(times, dep_est, ref_est, dist_lim, dep_lim, ref_lim)
    [nr,nc] = size(times);
    combined_times = cell(nr,nc);
    for i = 1:nr
        for j = 1:nc
            combined_times{i,j} = times{i,j};
            for i1 = (max(1, i-dist_lim)) : min(nr, i+dist_lim)
                for j1 = (max(1, j-dist_lim)) : min(nc, j+dist_lim)
                    if i == i1 && j == j1
                        continue
                    end
                    if abs(dep_est(i,j) - dep_est(i1,j1))<dep_lim && abs(ref_est(i,j)-ref_est(i1,j1))<ref_lim
                        combined_times{i,j} = [combined_times{i,j}; times{i1,j1}];
                    end
                end
            end

        end
    end 
end


