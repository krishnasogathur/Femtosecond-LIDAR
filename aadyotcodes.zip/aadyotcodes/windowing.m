function censored_times = windowing(times, window)
    [nr,nc] = size(times);
    censored_times = cell(nr,nc);
    for i = 1:nr
        for j = 1:nc
            censored_times{i,j} = censor_single(times{i,j}, window);
        end
    end
end

function censored_times = censor_single(times, window)
    if isempty(times)
        censored_times = times;
        return;
    end

    times = sort(times);
    maxcount = 0;
    maxcountidx = 1;
    for i = 1 : length(times)
        j = i;
        while (j <= length(times)) && (times(j) - times(i) < window)
            j = j+1;
        end

        if(j-i)>maxcount
            maxcount = j-1-i;
            maxcountidx = i;
        end
    end
    censored_times = times(maxcountidx: maxcountidx+maxcount);
end