function [avg_tof,counts] = estimating(Ts)
    [nr,nc] = size(Ts);
    avg_tof = zeros(nr,nc);
    counts = zeros(nr,nc);
    for i = 1:nr
        for j = 1:nc
            avg_tof(i,j) = mean(Ts{i,j});
            counts(i,j) = length(Ts{i,j});
        end
    end
end